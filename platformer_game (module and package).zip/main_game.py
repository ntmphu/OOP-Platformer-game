import pygame
import sys
from utils import *
from player import Player
from object import Block
from map import Map
from menu import Menu

class MAIN_GAME:
    """
    A class to represent the main game logic and control flow.

    Attributes:
    -----------
    player : Player
        The player character.
    block_size : int
        The size of each block in the game.
    map_data : list
        The map data for different levels.
    map : Map
        The map object containing the game levels.
    name_background : list
        List of background image filenames for each level.
    platform_count : int
        Counter for platforms reached by the player.
    reset : bool
        Flag to reset the game state.
    lives : list
        List of Block objects representing the player's lives.
    offset_x : int
        Offset for horizontal scrolling.
    scroll_area_width : int
        Width of the scroll area to trigger scrolling.
    menu : Menu
        The menu object for displaying menus.
    in_menu : bool
        Flag indicating if the game is currently displaying a menu.
    game_over : bool
        Flag indicating if the game is over.

    Methods:
    --------
    loop(FPS: int) -> None:
        Main game loop for updating player and fire animations.
    collide(dx: int) -> Block or None:
        Checks for horizontal collisions and returns the collided object.
    handle_vertical_collision(dy: int) -> list:
        Handles vertical collisions and returns a list of collided objects.
    operate_game() -> None:
        Handles player movements, collisions, and game state transitions.
    reset_game() -> None:
        Resets the game state to the beginning of the level.
    draw(window: pygame.Surface) -> None:
        Draws the game elements on the given window.
    scroll() -> None:
        Handles horizontal scrolling based on player movement.
    end_game(win: bool = False, lose: bool = False) -> None:
        Ends the game and shows the appropriate menu.
    handle_events() -> None:
        Handles pygame events such as keyboard and mouse inputs.
    """

    def __init__(self):
        """Initializes the MAIN_GAME with default values and setups."""
        self.player = Player(200, 200, 50, 50)
        self.block_size = 96
        self.map_data = [
            ["00000000020000000000011111110000000000000011000000000000001111110000000000000",
             "03000001111000000012000202000000000200000111120000000000120000000200000004000",
             "11111111111111111111111111111111111111111111111111111111111111111111111111111"],
            ["0000000000011110000000000000000110000002000000000001111110000000000000000",
             "0300000001002000001002111100212000000011112000000100000000000200000004000",
             "1111111111111111111111111112111111111111111111211121111111111111111111111"],
            ["00000000001200000000000000000000000222000222000000001110001100000000000000",
             "03000000011100000000111001100000000000000000000000100020102000200000004000",
             "11111122111111111111222222211111111111121111111112111111111111111111111111"]
        ]
        self.map = Map(self.block_size, self.map_data)
        self.name_background = ["Blue.png", "Purple.png", "Green.png"]
        self.platform_count = 0
        self.reset = False
        lives_path = "assets\MainCharacters\MaskDude\jump.png"
        self.lives = [Block(10, 20, 96, "end", lives_path, (0, 0), (100, 100)),
                      Block(60, 20, 96, "end", lives_path, (0, 0), (100, 100)),
                      Block(110, 20, 96, "end", lives_path, (0, 0), (100, 100))]
        self.offset_x = 0
        self.scroll_area_width = 200
        self.menu = Menu()
        self.in_menu = True
        self.game_over = False

    def loop(self, FPS: int) -> None:
        """Main game loop for updating player and fire animations."""
        self.player.loop(FPS)
        for fire in self.map.fire:
            fire.loop()

    def collide(self, dx: int) -> Block or None:
        """
        Checks for horizontal collisions and returns the collided object.

        Parameters:
        -----------
        dx : int
            The horizontal displacement to check for collisions.

        Returns:
        --------
        Block or None
            The object the player collided with, or None if no collision.
        """
        self.player.move(dx, 0)
        self.player.update()
        collided_objects = None
        for obj in self.map.objects:
            if obj.name == "start":
                continue
            if self.player.rect.colliderect(obj.rect):
                collided_objects = obj
                break
        self.player.move(-dx, 0)
        self.player.update()
        return collided_objects

    def handle_vertical_collision(self, dy: int) -> list:
        """
        Handles vertical collisions and returns a list of collided objects.

        Parameters:
        -----------
        dy : int
            The vertical distance to check for collisions.

        Returns:
        --------
        list
            List of objects the player collided with.
        """
        collided_objects = []
        for obj in self.map.objects:
            if self.player.rect.colliderect(obj.rect):
                if dy > 0:
                    self.player.rect.bottom = obj.rect.top
                    self.player.landed()
                elif dy < 0:
                    self.player.rect.top = obj.rect.bottom
                    self.player.hit_head()
                collided_objects.append(obj)
        return collided_objects

    def operate_game(self) -> None:
        """Handles player movements, collisions, and game state transitions."""
        keys = pygame.key.get_pressed()
        self.player.x_vel = 0
        collide_left = self.collide(-PLAYER_VEL * 2)
        collide_right = self.collide(PLAYER_VEL * 2)

        if keys[pygame.K_LEFT] and not collide_left:
            self.player.move_left(PLAYER_VEL)
        if keys[pygame.K_RIGHT] and not collide_right:
            self.player.move_right(PLAYER_VEL)

        vertical_collide = self.handle_vertical_collision(self.player.y_vel)
        to_check = [collide_left, collide_right, *vertical_collide]

        for obj in to_check:
            if obj and obj.name == "fire":
                self.player.make_hit()
            if obj and obj.name == "end":
                self.platform_count += 1
                self.reset = True
                break
        if self.player.dead == 1:
            if len(self.lives) == 1:
                self.end_game(lose=True)
            self.lives.pop()
        if self.reset:
            if self.map.up_level == len(self.map.map_data) - 1:
                self.end_game(win=True)
                return
            self.map.next_level()
            self.reset_game()

    def reset_game(self) -> None:
        """Resets the game state to the beginning of the level."""
        self.reset = False
        self.player.rect.x = 100
        self.player.rect.y = 100
        self.offset_x = 0

    def draw(self, window: pygame.Surface) -> None:
        """
        Draws the game elements on the given window.

        Parameters:
        -----------
        window : pygame.Surface
            The window surface where the game elements will be drawn.
        """
        if self.in_menu:
            self.menu.draw(window)
        else:
            self.background, self.bg_image = get_background(self.name_background[self.map.up_level])
            for tile in self.background:
                window.blit(self.bg_image, tile)
            self.map.draw(window, self.offset_x)
            self.player.draw(window, self.offset_x)
            path = "assets\Items\Checkpoints\End\End (Idle).png"

            for i in range(self.platform_count):
                reward = Block(850 + 50 * i, 10, 96, "end", path, (0, 0), (64, 64))
                reward.draw(window, 0)
            for live in self.lives:
                live.draw(window, 0)
            pygame.display.update()

    def scroll(self) -> None:
        """Handles horizontal scrolling based on player movement."""
        if ((self.player.rect.right - self.offset_x >= WIDTH - self.scroll_area_width) and self.player.x_vel > 0) or ((self.player.rect.left - self.offset_x <= WIDTH - self.scroll_area_width) and self.player.x_vel < 0):
            self.offset_x += self.player.x_vel

    def end_game(self, win: bool = False, lose: bool = False) -> None:
        """
        Ends the game and shows the appropriate menu.

        Parameters:
        -----------
        win : bool, optional
            Flag indicating if the player won (default is False).
        lose : bool, optional
            Flag indicating if the player lost (default is False).
        """
        self.in_menu = True
        self.game_over = True
        if win:
            self.menu = Menu("win")
        elif lose:
            self.menu = Menu("lose")

    def handle_events(self) -> None:
        """
        Handles pygame events such as keyboard and mouse inputs.
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if self.in_menu:
                action = self.menu.handle_event(event)
                if action == 'start':
                    self.in_menu = False
                elif action == 'restart':
                    self.__init__()
                    self.in_menu = False
                elif action == 'quit':
                    pygame.quit()
                    sys.exit()
            else:
                if event.type == pygame.KEYDOWN:
                    if (event.key == pygame.K_SPACE or event.key == pygame.K_UP) and self.player.jump_count < 2:
                        self.player.jump()



