# Platformer

Nội dung trò chơi:

Người chơi sẽ điều khiển nhân vật né các vật cản (ngọn lửa) và thu thập vật phẩm. Trò chơi sẽ có 3 "platform" với độ khó tăng dần, vật phẩm là chiếc cúp được hiển thị ở cuối "platform". 

Nếu người chơi đụng ngọn lửa sẽ mất một mạng, mất 3 mạng là thua cuộc và trò chơi sẽ kết thúc. Để thắng cuộc, người chơi cần thu thập đủ 3 cúp. 

Thao tác:
Di chuyển trái/phải: mũi trên trái/phải
Nhảy: dấu cách/mũi tên lên
Lộn nhào trên không: dấu cách/mũi tên lên 2 lần