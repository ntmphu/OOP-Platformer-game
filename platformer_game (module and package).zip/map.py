from utils import *
from object import Block, Fire

class Map:
    """
    A class to represent a game map composed of different objects such as terrain, fire, and checkpoints.

    Attributes:
    -----------
    block_size : int
        The size of each block in the map.
    map_data : list
        A list of lists containing the map data for each level.
    levels : list
        A list to keep track of the loaded levels.
    up_level : int
        The current level index.
    objects : list
        A list to store Block objects present in the current level.
    fire : list
        A list to store Fire objects present in the current level.

    Methods:
    --------
    load_level(level: int) -> None:
        Loads the specified level, initializing the objects and fire lists.
    
    next_level() -> None:
        Advances to the next level and loads it.
    
    draw(window, offset_x) -> None:
        Draws the objects and fire on the given window with the specified offset.
    """
    
    def __init__(self, block_size: int, initial_map: list, start_level: int = 0):
        """
        Constructs all the necessary attributes for the Map object.

        Parameters:
        -----------
        block_size : int
            The size of each block in the map.
        initial_map : list
            A list of lists containing the map data for each level.
        start_level : int, optional
            The initial level to load (default is 0).
        """
        self.block_size = block_size
        self.map_data = initial_map
        self.levels = []
        self.up_level = start_level
        self.objects = []
        self.fire = []
        self.load_level(start_level)
        
    def load_level(self, level: int) -> None:
        """
        Loads the specified level, initializing the objects and fire lists.

        Parameters:
        -----------
        level : int
            The level index to load.
        """
        self.objects = []
        self.fire = []
        self.map = self.map_data[level][::-1]
        for y, row in enumerate(self.map):
            for x, col in enumerate(row):
                if col == "0":
                    continue
                elif col == "1":
                    path = "assets\\Terrain\\Terrain.png"
                    obj = Block(x * self.block_size, HEIGHT - (1 + y) * self.block_size, self.block_size, "terrain", path, (96, 0), (self.block_size * 2, self.block_size * 2))
                elif col == "2":
                    obj = Fire(x * self.block_size, HEIGHT - (y + 1) * self.block_size + 32, 16, 32)
                    self.fire.append(obj)
                elif col == "3":
                    path = "assets\\Items\\Checkpoints\\Start\\Start (Idle).png"
                    obj = Block(x * self.block_size, HEIGHT - (y + 1) * self.block_size, self.block_size, "start", path, (0, 0), (self.block_size * 2, self.block_size * 2))
                elif col == "4":
                    path = "assets\\Items\\Checkpoints\\End\\End (Idle).png"
                    obj = Block(x * self.block_size, HEIGHT - (y + 1) * self.block_size + 5, self.block_size + 40, "end", path, (0, 0), (self.block_size * 2, self.block_size * 2))
                self.objects.append(obj)

    def next_level(self) -> None:
        """
        Advances to the next level and loads it.
        """
        self.up_level += 1
        self.load_level(self.up_level)

    def draw(self, window, offset_x: int) -> None:
        """
        Draws the objects and fire on the given window with the specified offset.

        Parameters:
        -----------
        window :
            The window on which to draw the objects.
        offset_x : int
            The horizontal offset for drawing the objects.
        """
        for obj in self.objects:
            obj.draw(window, offset_x)
        for fire in self.fire:
            fire.draw(window, offset_x)
