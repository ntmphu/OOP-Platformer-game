import pygame
from utils import *

class Menu:
    """
    A class to represent different game menus (start, win, lose).

    Attributes:
    -----------
    menu_type : str
        The type of menu ("start", "win", "lose").
    font : pygame.font.Font
        The font used for the main title text.
    small_font : pygame.font.Font
        The font used for the smaller option text.
    title_text : pygame.Surface
        The surface for the main title text.
    quit_text : pygame.Surface, optional
        The surface for the quit text (only for "start" menu).
    option_text : pygame.Surface, optional
        The surface for the option text (only for "win" and "lose" menus).
    title_rect : pygame.Rect
        The rectangle for positioning the title text.
    start_rect : pygame.Rect, optional
        The rectangle for positioning the start text (only for "start" menu).
    quit_rect : pygame.Rect, optional
        The rectangle for positioning the quit text (only for "start" menu).
    option_rect : pygame.Rect, optional
        The rectangle for positioning the option text (only for "win" and "lose" menus).

    Methods:
    --------
    draw(window: pygame.Surface) -> None:
        Draws the menu on the given window.
    handle_event(event: pygame.event.Event) -> str or None:
        Handles events (mouse clicks and key presses) and returns the menu action.
    """

    def __init__(self, menu_type="start"):
        """
        Constructs all the necessary attributes for the Menu object.

        Parameters:
        -----------
        menu_type : str, optional
            The type of menu ("start", "win", "lose") (default is "start").
        """
        self.menu_type = menu_type
        self.font = pygame.font.Font(None, 74)
        self.small_font = pygame.font.Font(None, 50)
        
        if menu_type == "start":
            self.title_text = self.font.render('Start Game', True, (255, 255, 255))
            self.quit_text = self.font.render('Quit', True, (255, 255, 255))
        elif menu_type == "win":
            self.title_text = self.font.render('Congratulations! You Win!', True, (255, 255, 255))
            self.option_text = self.small_font.render('Press Enter to Restart or Esc to Quit', True, (255, 255, 255))
        elif menu_type == "lose":
            self.title_text = self.font.render('You Died', True, (255, 255, 255))
            self.option_text = self.small_font.render('Press Enter to Restart or Esc to Quit', True, (255, 255, 255))
        
        self.title_rect = self.title_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
        
        if menu_type != "start":
            self.option_rect = self.option_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 50))
        else:
            self.start_rect = self.title_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
            self.quit_rect = self.quit_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 50))

    def draw(self, window: pygame.Surface) -> None:
        """
        Draws the menu on the given window.

        Parameters:
        -----------
        window : pygame.Surface
            The window surface where the menu will be drawn.
        """
        window.fill((0, 0, 0))
        window.blit(self.title_text, self.title_rect)
        if self.menu_type != "start":
            window.blit(self.option_text, self.option_rect)
        else:
            window.blit(self.title_text, self.start_rect)
            window.blit(self.quit_text, self.quit_rect)
        pygame.display.update()

    def handle_event(self, event: pygame.event.Event) -> str or None:
        """
        Handles events (mouse clicks and key presses) and returns the menu action.

        Parameters:
        -----------
        event : pygame.event.Event
            The event to handle.

        Returns:
        --------
        str or None
            The action to perform based on the event ('start', 'quit', 'restart') or None if no action.
        """
        if self.menu_type == "start":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.start_rect.collidepoint(event.pos):
                    return 'start'
                elif self.quit_rect.collidepoint(event.pos):
                    return 'quit'
        elif self.menu_type in ["win", "lose"]:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return 'restart'
                elif event.key == pygame.K_ESCAPE:
                    return 'quit'
        return None
