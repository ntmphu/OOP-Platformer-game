import pygame
from utils import load_sprite_sheets

class Player:
    """
    A class to represent the player character in the game.

    Attributes:
    -----------
    GRAVITY : int
        The gravitational force applied to the player.
    SPRITES : dict
        A dictionary containing the player's sprite sheets.
    ANIMATION_DELAY : int
        The delay between animation frames.
    rect : pygame.Rect
        The rectangle representing the player's position and dimensions on screen.
    x_vel : int
        The velocity of the player along the x-axis.    
    y_vel : int
        The velocity of the player along the y-axis.    
    direction : str
        The direction the player is facing, either "Left" or "Right". Default is "Right".    
    animation_count : int
        Counter for the current frame in the animation sequence.    
    fall_count : int
        Counter for tracking how long the player has been falling.    
    hit : bool
        Flag indicating whether the player has been hit or not.    
    hit_count : int
        Counter for how long the player has been in the hit state.    
    jump_count : int
        Counter for the number of jumps the player has performed.    
    dead : int
        Counter for tracking the player's death state.    
    sprite : pygame.Surface or None
        The current sprite image of the player. None if no sprite is assigned.

    Methods:
    --------
    move(dx: int, dy: int) -> None:
        Moves the player by the specified amounts.
    make_hit() -> None:
        Sets the player to the hit state.
    move_left(vel: int) -> None:
        Moves the player to the left with the specified velocity.
    move_right(vel: int) -> None:
        Moves the player to the right with the specified velocity.
    jump() -> None:
        Makes the player jump.
    update() -> None:
        Updates the player's rectangle based on the current sprite.
    loop(fps: int) -> None:
        Updates the player's position and state for each frame.
    landed() -> None:
        Resets the player's fall count and vertical velocity when they land.
    hit_head() -> None:
        Inverts the player's vertical velocity when they hit their head.
    update_sprite() -> None:
        Updates the player's sprite based on their current state and direction.
    draw(win: pygame.Surface, offset_x: int) -> None:
        Draws the player on the given window with the specified horizontal offset.
    """
    
    
    
    def __init__(self, x: int, y: int, width: int, height: int):
        """
        Constructs all the necessary attributes for the Player object.

        Parameters:
        -----------
        x : int
            The x-coordinate of the player's position.
        y : int
            The y-coordinate of the player's position.
        width : int
            The width of the player's rectangle.
        height : int
            The height of the player's rectangle.
            
        """
        self.rect = pygame.Rect(x, y, width, height)
        self.x_vel = 0
        self.y_vel = 0
        self.direction = "right"
        self.animation_count = 0
        self.fall_count = 0
        self.hit = False
        self.hit_count = 0
        self.jump_count = 0
        self.dead = 0
        self.sprite = None
        self.GRAVITY = 1
        self.SPRITES = load_sprite_sheets(32, 32, "assets\\MainCharacters\\MaskDude", True)
        self.ANIMATION_DELAY = 3

    def move(self, dx: int, dy: int) -> None:
        """Moves the player by the specified amounts."""
        self.rect.x += dx
        self.rect.y += dy    

    def make_hit(self) -> None:
        """Sets the player to the hit state."""
        self.hit = True
        self.hit_count = 0
        self.dead = 0
    
    def move_left(self, vel: int) -> None:
        """Moves the player to the left with the specified velocity."""
        self.x_vel = -vel
        if self.direction != "left":
            self.direction = "left"
            self.animation_count = 0

    def move_right(self, vel: int) -> None:
        """Moves the player to the right with the specified velocity."""
        self.x_vel = vel
        if self.direction != "right":
            self.direction = "right"
            self.animation_count = 0

    def jump(self) -> None:
        """Makes the player jump."""
        self.y_vel = -self.GRAVITY * 8
        self.animation_count = 0
        self.jump_count += 1
        if self.jump_count == 1:
            self.fall_count = 0

    def update(self) -> None:
        """Updates the player's rectangle based on the current sprite."""
        self.rect = self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))

    def loop(self, fps: int) -> None:
        """Updates the player's position and state for each frame."""
        self.y_vel += min(1, (self.fall_count / fps) * self.GRAVITY)
        self.move(self.x_vel, self.y_vel)
        if self.hit:
            self.hit_count += 1
        if self.hit_count > fps:
            self.hit = False
            self.dead += 1
            if self.dead > fps:
                self.dead = 2
        self.fall_count += 1
        self.update_sprite()

    def landed(self) -> None:
        """Resets the player's fall count and vertical velocity when they land."""
        self.fall_count = 0
        self.y_vel = 0
        self.jump_count = 0

    def hit_head(self) -> None:
        """Inverts the player's vertical velocity when they hit their head."""
        self.fall_count = 0
        self.y_vel *= -1
    
    def update_sprite(self) -> None:
        """Updates the player's sprite based on their current state and direction."""
        sprite_sheet = "idle"
        if self.hit:
            sprite_sheet = "hit"
        elif self.x_vel != 0:
            sprite_sheet = "run"
        elif self.y_vel > self.GRAVITY * 2:
            sprite_sheet = "fall"
        elif self.y_vel < 0:
            if self.jump_count == 1:
                sprite_sheet = "jump"
            elif self.jump_count == 2:
                sprite_sheet = "double_jump"
        
        sprite_sheet_name = sprite_sheet + "_" + self.direction
        sprites = self.SPRITES[sprite_sheet_name]
        sprite_index = (self.animation_count // self.ANIMATION_DELAY) % len(sprites)
        self.sprite = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))

    def draw(self, win: pygame.Surface, offset_x: int) -> None:
        """Draws the player on the given window with the specified horizontal offset."""
        win.blit(self.sprite, (self.rect.x - offset_x, self.rect.y))
