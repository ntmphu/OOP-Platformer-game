import pygame
from utils import load_sprite_sheets

class Object:
    """
    A class to represent a generic object (physical entity) in the game.

    Attributes:
    -----------
    rect : pygame.Rect
        The rectangle representing the object's position and size.
    image : pygame.Surface
        The surface for the object's image.
    width : int
        The width of the object.
    height : int
        The height of the object.
    name : str
        The name of the object.
    path : str
        The path to the object's image file.
    topleft : tuple
        The top-left coordinate for cropping the image.
    scale : tuple
        The scale to which the object image should be resized.

    Methods:
    --------
    draw(win: pygame.Surface, offset_x: int) -> None:
        Draws the object on the given window with the specified horizontal offset.
    get_block(size: int, topleft: tuple) -> pygame.Surface:
        Crops the object's image from the specified top-left corner and scales it.
    """

    def __init__(self, x: int, y: int, width: int, height: int, name: str, path: str, topleft=(0, 0), scale=(192, 192)):
        """
        Constructs all the necessary attributes for the Object object.

        Parameters:
        -----------
        x : int
            The x-coordinate of the object's position.
        y : int
            The y-coordinate of the object's position.
        width : int
            The width of the object's rectangle.
        height : int
            The height of the object's rectangle.
        name : str
            The name of the object.
        path : str
            The path to the object's image file.
        topleft : tuple, optional
            The top-left coordinate for cropping the image (default is (0, 0)).
        scale : tuple, optional
            The scale to which the object image should be resized (default is (192, 192)).
        """
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.width = width
        self.height = height
        self.name = name
        self.path = path
        self.topleft = topleft
        self.scale = scale

    def draw(self, win: pygame.Surface, offset_x: int) -> None:
        """Draws the object on the given window with the specified horizontal offset."""
        win.blit(self.image, (self.rect.x - offset_x, self.rect.y))

    def get_block(self, size: int, topleft: tuple) -> pygame.Surface:
        """
        Crops the object's image from the specified top-left corner and scales it.

        Parameters:
        -----------
        size : int
            The size of the block to be cropped.
        topleft : tuple
            The top-left coordinate for cropping the image.

        Returns:
        --------
        pygame.Surface
            The cropped and scaled image surface.
        """
        image = pygame.image.load(self.path).convert_alpha()
        surface = pygame.Surface((size, size), pygame.SRCALPHA, 32)
        rect = pygame.Rect(topleft[0], topleft[1], size, size)
        surface.blit(image, (0, 0), rect)
        return pygame.transform.scale(surface, self.scale)

class Block(Object):
    """
    A class to represent a block object in the game (such as terrain, lives, start checkpoint, end checkpoint,...), inheriting from Object.

    Methods:
    --------
    draw_block() -> None:
        Draws the block image on the object's surface.
    """

    def __init__(self, x: int, y: int, size: int, name: str, path: str, topleft: tuple, scale: tuple):
        """
        Constructs all the necessary attributes for the Block object.

        Parameters:
        -----------
        x : int
            The x-coordinate of the block's position.
        y : int
            The y-coordinate of the block's position.
        size : int
            The size of the block.
        name : str
            The name of the block.
        path : str
            The path to the block's image file.
        topleft : tuple
            The top-left coordinate for cropping the block's image.
        scale : tuple
            The scale to which the block image should be resized.
        """
        super().__init__(x, y, size, size, name, path, topleft, scale)
        self.block = self.get_block(size, topleft)
        self.draw_block()

    def draw_block(self) -> None:
        """Draws the block image on the object's surface."""
        self.image.blit(self.block, (0, 0))

class Fire(Object):
    """
    A class to represent a fire object in the game, inheriting from Object.

    Attributes:
    -----------
    ANIMATION_DELAY : int
        The delay between animation frames.
    fire : dict
        A dictionary containing the fire's sprite sheets.
    animation_count : int
        The current frame count for animation.
    animation_name : str
        The current animation state ("on" or "off").

    Methods:
    --------
    on() -> None:
        Sets the fire animation to "on".
    off() -> None:
        Sets the fire animation to "off".
    loop() -> None:
        Updates the fire's animation based on the current state.
    """

    ANIMATION_DELAY = 3

    def __init__(self, x: int, y: int, width: int, height: int):
        """
        Constructs all the necessary attributes for the Fire object.

        Parameters:
        -----------
        x : int
            The x-coordinate of the fire's position.
        y : int
            The y-coordinate of the fire's position.
        width : int
            The width of the fire's rectangle.
        height : int
            The height of the fire's rectangle.
        """
        path = "assets/Traps/Fire"
        super().__init__(x, y, width, height, "fire", path)
        self.fire = load_sprite_sheets(width, height, path)  # all "on", "off"
        self.image = self.fire["off"][0]
        self.animation_count = 0
        self.animation_name = "on"

    def on(self) -> None:
        """Sets the fire animation to "on"."""
        self.animation_name = "on"

    def off(self) -> None:
        """Sets the fire animation to "off"."""
        self.animation_name = "off"

    def loop(self) -> None:
        """Updates the fire's animation based on the current state."""
        sprites = self.fire[self.animation_name]
        sprite_index = (self.animation_count // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))

        if self.animation_count // self.ANIMATION_DELAY > len(sprites):
            self.animation_count = 0
