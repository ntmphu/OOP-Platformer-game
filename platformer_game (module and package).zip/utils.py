import pygame, sys
from os import listdir
from os.path import isfile, join
pygame.init()
pygame.display.set_caption("Platformer")
BG_COLOR = (255,255,255) #while
WIDTH, HEIGHT = 1000, 600
FPS = 60
PLAYER_VEL = 5 #SPEED
window = pygame.display.set_mode((WIDTH, HEIGHT))



def flip(sprites):
  return [pygame.transform.flip(sprite, True, False) for sprite in sprites] #True and False here is flip in x and y direction respectively -> so this is to flip in x direction

def load_sprite_sheets(width, height, path, direction = False): 
  #width is pixel of each individual image in the sprite sheet
  images = [f for f in listdir(path) if isfile(join(path, f))] #append all image's address if exist in the assets\dir1\dir2
  all_sprites = {}
  #load each image in images
  for image in images: 
    sprite_sheet = pygame.image.load(join(path, image)).convert_alpha() 
    #convert alpha allow to load a transparent background image
    sprites = []
    
    for i in range(sprite_sheet.get_width() // width):
      surface = pygame.Surface((width, height), pygame.SRCALPHA, 32) # creates a new 32-bit Pygame surface with an alpha channel (for transparency) and a size of (width, height) pixels
      rect = pygame.Rect(i*width, 0, width, height)
      surface.blit(sprite_sheet, (0,0), rect) #draw the rect frame of the sprite_sheet at position 0,0 of the surface
      sprites.append(pygame.transform.scale2x(surface))
      
    if direction:
      all_sprites[image.replace(".png", "") + "_right"] = sprites
      all_sprites[image.replace(".png", "") + "_left"] = flip(sprites)
    else:
      all_sprites[image.replace(".png", "")] = sprites
  return all_sprites

def get_background(name):
  image = pygame.image.load(join("assets", "Background", name))
  _, _, width, height = image.get_rect()
  tiles = []

  for i in range(WIDTH//width + 1):
    for j in range(HEIGHT//height + 1):
      pos = (i*width, j*height)
      tiles.append(pos)
  return tiles, image
