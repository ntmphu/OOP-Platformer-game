
from utils import *
from main_game import MAIN_GAME

def main():
    game = MAIN_GAME()
    clock = pygame.time.Clock()
    while True:
        game.handle_events()
        if not game.in_menu:
            game.loop(FPS)
            game.operate_game()
            game.scroll()
        game.draw(window)
        clock.tick(FPS)

if __name__ == "__main__":
    main()
   

       
